function doSomething() {
	alert("Hello");
}